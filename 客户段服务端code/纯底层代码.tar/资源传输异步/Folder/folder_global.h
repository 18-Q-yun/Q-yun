#ifndef FOLDER_GLOBAL_H
#define FOLDER_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(FOLDER_LIBRARY)
#  define FOLDERSHARED_EXPORT Q_DECL_EXPORT
#else
#  define FOLDERSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // FOLDER_GLOBAL_H
