#ifndef RESOURCETRANSMISSION_H
#define RESOURCETRANSMISSION_H

#include <iostream>
#include <fstream>
#include <string>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include "resourcetransmission_global.h"
#include "session头文件/session.h"

class RESOURCETRANSMISSIONSHARED_EXPORT ResourceTransmission
{
public:
    void serverUploadResource(std::shared_ptr<Session> pSession);
    void serverDownloadResource(std::shared_ptr<Session> pSession);

    void clientUploadResource(std::shared_ptr<Session> pSession);
    void clientDownloadResource(std::shared_ptr<Session> pSession);

    std::string getResourceName(std::string resourceName);
    void to_char(char c[], int i);
};

#endif // RESOURCETRANSMISSION_H
