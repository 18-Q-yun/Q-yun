#include "resourcetransmission.h"
#include "foldr头文件/folder.h"

#define MAX_DATA_LENGTH 1448

using std::cout; using std::endl;
using std::string;
using namespace boost::asio;

//---------------------------------------------Server------------------------------------------
void ResourceTransmission::serverUploadResource(std::shared_ptr<Session> pSession)
{
    string resourcePath;
    char str[MAX_DATA_LENGTH];
    try{
        pSession->getSocket().read_some(buffer(str, MAX_DATA_LENGTH));
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    //传输到相应的文件夹中
    string resourceName = str;
    resourcePath = "/root/uploadResource";
    Folder folder(resourcePath);
    bool flag = folder.exitDirectory();
    while(!flag)
        flag = folder.createDirectory();
    string resource =  resourcePath + "/" + resourceName;

    //接受数据长度
    int ilength ;
    try{
        pSession->getSocket().read_some(buffer(str, MAX_DATA_LENGTH));
        string length = str;
        ilength = std::stoi (length);
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }
    cout << "The length is " << ilength << endl;
    //计算传输次数
    int num = 0;
    if(ilength < MAX_DATA_LENGTH)
        num = 1;
    else if(ilength >= MAX_DATA_LENGTH) {
        int reminder = ilength % MAX_DATA_LENGTH;
        if(reminder == 0)
            num = ilength / MAX_DATA_LENGTH;
        else
            num = (ilength / MAX_DATA_LENGTH) + 1;
    }

    std::ofstream ofs(resource, std::ios::binary);

    int i = 0;
    int n = 0;
    try{
        while (i++ < num) {
            size_t data =  pSession->getSocket().read_some(buffer(str));
            //丢包重传
            while(data != MAX_DATA_LENGTH && i < num - 1) {
                pSession->getSocket().write_some(buffer("again"));
                data =  pSession->getSocket().read_some(buffer(str));
            }
            pSession->getSocket().write_some(buffer("ok"));
            n += data;
            ofs.write(str, data);
        }
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    cout << n << endl;
    ofs.close();
}

void ResourceTransmission::serverDownloadResource(std::shared_ptr<Session> pSession)
{
    char str[MAX_DATA_LENGTH];
    try{
        pSession->getSocket().read_some(buffer(str, MAX_DATA_LENGTH));
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    //传输到相应的文件夹中
    string resourcePath = "/root/downloadResource";
    Folder folder(resourcePath);
    bool flag = folder.exitDirectory();
    cout << flag << endl;
    while(!flag)
        flag = folder.createDirectory();

    string resource = str;
    std::ifstream ifs(resource,std::ios::binary);
    ifs.seekg(0, std::ios::end);
    int size = ifs.tellg();
    to_char(str, size);
    cout << "The size is " << str << endl;
    try{
        pSession->getSocket().write_some(buffer(str, MAX_DATA_LENGTH));
        if(ifs){
            ifs.seekg(0, ifs.beg);
            int offset = 0;
            int readSize = std::min(MAX_DATA_LENGTH, size - offset);
            char boo[] = "again";
            while(readSize > 0) {
                ifs.read(str, readSize);
                pSession->getSocket().write_some(buffer(str, readSize));
                //丢包重传
                pSession->getSocket().read_some(buffer(str));
                while(str == boo) {
                    pSession->getSocket().write_some(buffer(str, readSize));
                    pSession->getSocket().read_some(buffer(str));
                }
                offset += readSize;
                readSize = std::min(MAX_DATA_LENGTH, size - offset);
                std::cout << "offset:" << offset << std::endl;
            }
        }
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }
    ifs.close();
}

//-----------------------------------------Client----------------------------------------

void ResourceTransmission::clientUploadResource(std::shared_ptr<Session> pSession)
{
    char str[MAX_DATA_LENGTH];
    cout << "The resource path: ";
    string resource;
    std::cin >> resource;
    string resourceName = getResourceName(resource);
    resourceName.copy(str, resourceName.size(), 0);
    *(str + resourceName.size()) = '\0';
    cout << str << endl;
    try{
        pSession->getSocket().write_some(buffer(str, MAX_DATA_LENGTH));
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    //资源名字

    std::ifstream ifs(resource, std::ios::binary);
    ifs.seekg(0, std::ios::end);
    int size = ifs.tellg();
    to_char(str, size);
    cout << "The size is " << str << endl;
    try{
        pSession->getSocket().write_some(buffer(str, MAX_DATA_LENGTH));
        if(ifs){
            ifs.seekg(0, ifs.beg);
            int offset = 0;
            int readSize = std::min(MAX_DATA_LENGTH, size - offset);
            char boo[] = "again";
            while(readSize > 0) {
                ifs.read(str, readSize);
                pSession->getSocket().write_some(buffer(str, readSize));
                //丢包重传
                pSession->getSocket().read_some(buffer(str));
                while(str == boo) {
                    pSession->getSocket().write_some(buffer(str, readSize));
                    pSession->getSocket().read_some(buffer(str));
                }
                offset += readSize;
                readSize = std::min(MAX_DATA_LENGTH, size - offset);
                cout << "offset: " << offset << endl;
            }
        }

    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }
    ifs.close();
}

void ResourceTransmission::clientDownloadResource(std::shared_ptr<Session> pSession)
{
    char str[MAX_DATA_LENGTH];

    cout << "The resource name" << endl;
    string resource;
    std::cin >> resource;

    resource.copy(str, resource.size(), 0);
    *(str + resource.size()) = '\0';
    try{
        pSession->getSocket().write_some(buffer(str, MAX_DATA_LENGTH));
        pSession->getSocket().read_some(buffer(str, MAX_DATA_LENGTH));//get resource size
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    string length = str;
    int ilength = std::stoi (length);
    cout << "The length is " << ilength << endl;
    //计算传输次数
    int num = 0;
    if(ilength < MAX_DATA_LENGTH)
        num = 1;
    else if(ilength >= MAX_DATA_LENGTH) {
        int reminder = ilength % MAX_DATA_LENGTH;
        if(reminder == 0)
            num = ilength / MAX_DATA_LENGTH;
        else
            num = (ilength / MAX_DATA_LENGTH) + 1;
    }

    //传输到相应的文件夹中
    string resourceName = getResourceName(resource);
    string resourcePath = "/root/downloadResource";
    string downloadResource = resourcePath + "/" + resourceName;
    std::ofstream ofs(downloadResource, std::ios::binary);

    int i = 0;
    int n = 0;
    try{
        while (i++ < num) {
            size_t data =  pSession->getSocket().read_some(buffer(str));
            //丢包重传
            while(data != MAX_DATA_LENGTH && i < num - 1) {
                pSession->getSocket().write_some(buffer("again"));
                data =  pSession->getSocket().read_some(buffer(str));
            }
            pSession->getSocket().write_some(buffer("ok"));
            n += data;
            ofs.write(str, data);
        }
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    cout << n << endl;
    ofs.close();
}

//----------------------------------General----------------------------------------------

void ResourceTransmission::to_char(char c[], int i)
{
    string s = std::to_string(i);
    s.copy(c, s.size(), 0);
    *(c + s.size()) = '\0';
}


std::string ResourceTransmission::getResourceName(std::string resourceName)
{
    auto reIterator = resourceName.end();
    while(*reIterator-- != '/');
    string name;
    reIterator++;
    while(reIterator++ != resourceName.end())
        name += *reIterator;
    return name;
}
