#ifndef RESOURCESERVER_H
#define RESOURCESERVER_H

#include <iostream>
#include <fstream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include "session头文件/session.h"

class ResourceServer
{
public:
    ResourceServer(boost::asio::io_service &io): _io(io), _acceptor(io,  boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), 2001) ){}
    void start_accept();
    void handle_accept(std::shared_ptr<Session> pSession, const boost::system::error_code &err);
    void selectWay(std::shared_ptr<Session> pSession);


private:
    boost::asio::io_service &_io;
    boost::asio::ip::tcp::acceptor _acceptor;
};

#endif // RESOURCESERVER_H
