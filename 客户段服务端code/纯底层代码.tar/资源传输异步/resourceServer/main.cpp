#include <iostream>
#include "resourceserver.h"
#include "resourceTransmission头文件/resourcetransmission.h"

using namespace boost::asio;
using std::cout; using std::endl;
using std::stoi; using std::string;

int main()
{
    try{
        io_service my_io;
        ResourceServer MyServer(my_io);
        MyServer.start_accept();
        my_io.run();
    }
    catch (std::exception& _e) {
        std::cout << _e.what() << std::endl;
    }
    return 0;
}
