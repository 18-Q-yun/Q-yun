#ifndef SESSION_H
#define SESSION_H

#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include "session_global.h"

class SESSIONSHARED_EXPORT Session
{

public:
    Session(boost::asio::io_service &iosev):m_socket(boost::asio::ip::tcp::socket(iosev)){}

    boost::asio::ip::tcp::socket& getSocket(){return m_socket;}

private:
    boost::asio::ip::tcp::socket m_socket;
};

#endif // SESSION_H
