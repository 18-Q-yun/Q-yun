#ifndef SESSION_GLOBAL_H
#define SESSION_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SESSION_LIBRARY)
#  define SESSIONSHARED_EXPORT Q_DECL_EXPORT
#else
#  define SESSIONSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // SESSION_GLOBAL_H
