#ifndef RESOURCECLIENT_H
#define RESOURCECLIENT_H

#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include "session头文件/session.h"

class ResourceClient
{
public:
    ResourceClient(boost::asio::io_service &io):_io(io){}
    void start_connect();
    void connect_handler(std::shared_ptr<Session> pSession, const boost::system::error_code &err);
    void selectWay(std::shared_ptr<Session> pSession);

private:
    boost::asio::io_service &_io;
};

#endif // RESOURCECLIENT_H
