#include "conclient.h"
#include "resourceTraansmission头文件/resourcetransmission.h"

using namespace boost::asio;
using std::cout; using std::endl;

void ConClient::start_connect()
{
    std::shared_ptr<Session> pSession(new Session(_io));
    try{
        pSession->getSocket().async_connect(ip::tcp::endpoint(ip::address::from_string("127.0.0.1"), 2001), boost::bind( &ConClient::connect_handler, this, pSession, _1));
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }
}

void ConClient::connect_handler(std::shared_ptr<Session> pSession, const boost::system::error_code &err)
{
    if(err) return;
    cout << "receive from" << pSession->getSocket().remote_endpoint().address() << endl;
//    selectWay(pSession);
}

void ConClient::selectWay(std::shared_ptr<Session> pSession)
{
    char act[4];
    ResourceTransmission rt;

    try{
        pSession->getSocket().write_some(buffer(act, 4));
    } catch(std::exception& _e) {
        cout << _e.what() << endl;
    }

    if(*act == 'd')
        rt.clientDownloadResource(pSession);
    if(*act == 's')
        rt.clientUploadResource(pSession);
}
