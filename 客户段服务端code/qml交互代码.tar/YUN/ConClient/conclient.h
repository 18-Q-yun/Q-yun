#ifndef CONCLIENT_H
#define CONCLIENT_H

#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include "session头文件/session.h"
#include "conclient_global.h"

class CONCLIENTSHARED_EXPORT ConClient
{
public:
    ConClient(boost::asio::io_service &io):_io(io){}
    void start_connect();
    void connect_handler(std::shared_ptr<Session> pSession, const boost::system::error_code &err);
    void selectWay(std::shared_ptr<Session> pSession);

private:
    boost::asio::io_service &_io;
};

#endif // CONCLIENT_H
