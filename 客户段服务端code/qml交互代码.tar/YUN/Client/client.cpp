#include <boost/asio.hpp>
#include <iostream>
#include "client.h"
#include "Conclient头文件/conclient.h"

using namespace boost::asio;
using std::cout; using std::endl;

void Client::createClient()
{
    try{
        io_service my_io;
        ConClient MyClient(my_io);
        MyClient.start_connect();
        my_io.run();
    } catch (std::exception& _e) {
        cout << _e.what() << endl;
    }
}
