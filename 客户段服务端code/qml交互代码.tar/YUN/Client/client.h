#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include "client_global.h"

class CLIENTSHARED_EXPORT Client: public QObject
{
    Q_OBJECT
public:
    Q_INVOKABLE Client(){}
    Q_INVOKABLE void createClient();
    Q_INVOKABLE void downloadResource();
    Q_INVOKABLE void uploadResource();
};

#endif // CLIENT_H
